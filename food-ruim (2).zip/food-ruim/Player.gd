extends CharacterBody2D

const SPEED = 400.0
const JUMP_VELOCITY = -400.0

func _physics_process(delta: float) -> void:
	# Adiciona a gravidade se não estiver no chão
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Movimento automático em linha reta (para a direita)
	velocity.x = SPEED

	# Condição de pulo: aceita "Espaço", "Seta para Cima" ou "W"
	if is_on_floor() and (Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W)):
		velocity.y = JUMP_VELOCITY

	move_and_slide()
